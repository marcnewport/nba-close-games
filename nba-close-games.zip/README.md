# nba-close-games
A chrome extension that highlights which games were/are within 3 points on watch.nba.com (useful when scores are off).

https://chrome.google.com/webstore/detail/nba-close-games/fjjgljnmaijpilbcgbedemcnpffjkaaj
