# NBA Close Games for Chrome

## About
A chrome extension for http://watch.nba.com that highlights if a game went into over-time or the score differential is 3 points or less. Useful if you don't watch the games live and have spoilers turned off.

## Install 
https://chrome.google.com/webstore/detail/nba-close-games/fjjgljnmaijpilbcgbedemcnpffjkaaj
